export const users = [
  {
    name: 'Adam Romański',
    attendance: '39%',
    average: '2.3',
  },
  {
    name: 'Krzysztof Batko',
    attendance: '23%',
    average: '3.3',
  },
  {
    name: 'Patrycja Gonciarz',
    attendance: '45%',
    average: '4.3',
  },
  {
    name: 'Olga Hahn',
    attendance: '56%',
    average: '4.1',
  },
  {
    name: 'Paweł Andrzejewski',
    attendance: '29%',
    average: '2.4',
  },
  {
    name: 'Paweł Roman',
    average: '2.4',
  },
];
